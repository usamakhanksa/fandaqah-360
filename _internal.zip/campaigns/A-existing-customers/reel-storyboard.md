# Campaign A · Reel storyboard (25 s, 1080×1920)

Make the problem visible in the first three seconds. Show the **live product with sample data**; no guest identities.
Captions burned in (most views are muted). Keep text inside the safe area: 250 px clear at the top and bottom.
Keyframes for the editor: `creatives/reel-frames/A-reel-1…4-ar.jpg` (and `-en`).

**The thread:** the three manual records in the hook (purchase spreadsheet, paper room log, month-end by hand) are the
modules ticked at 10–20 s: purchasing, housekeeping, accounting. Set them up in the first shot so the proof pays them off.

| Time | What viewers see | On screen (Arabic) | On screen (English) | Voice-over (Arabic) | Voice-over (English) |
|---|---|---|---|---|---|
| 0–3 s | A hotel manager switching between a purchase spreadsheet, a paper room log and a month-end report done by hand | تستخدم فندقة؟ احصل على قيمة أكبر. | Already with Fandaqah? Get more value. | ما زلت على الورق وجداول البيانات؟ | Still on paper and spreadsheets? |
| 3–10 s | Accounting and purchasing, two modules this customer does not use yet, opening inside the Fandaqah screen they already know | اربط مزيداً من عملك اليومي. | Connect more of your daily work. | المحاسبة والمشتريات تنضمّان إلى فندقة التي تستخدمها. | Accounting and purchasing join the Fandaqah you already use. |
| 10–20 s | The five modules ticked in turn (accounting, purchasing, housekeeping, maintenance, inventory), then one task in the live product: a purchase order reaching accounting without being entered again | اكتشف ما تشمله ترقيتك. | See what your upgrade includes. | والمزيد من الخدمات الأخرى. | And many more services. |
| 20–25 s | The launch-price card: a padlock closing on SAR 3,495, the gold 30-day seal beside it, then the button | سعر الإطلاق الآن، وسنة إضافية بالسعر نفسه. | The launch price, plus a year at the same rate. | احجز سعر الإطلاق اليوم، مع خيار سنة ثانية بالسعر نفسه. | Reserve the launch price today, with the option of a second year at the same rate. |

**Supporting lines on screen:** 3–10 s «النظام نفسه والفريق نفسه، وجزء أكبر من فندقك مترابط.» / "Same system, same team,
more of your hotel." · 20–25 s «فندقة 360 بجميع المزايا والخدمات المتوفرة: 3,495 ريال / سنوياً غير شاملة الضريبة. ضمان ذهبي لمدة 30 يوماً.» / "Fandaqah 360 with all available features and services: SAR 3,495 / year, excl. VAT. 30-day Golden Guarantee."

**Voice-over timing:** about 5, 9, 11 and 5 words, so each line reads comfortably beside its headline when muted.
The 10–20 s caption points past the five ticked modules to the rest of the platform (20+ modules).

**End card:** logo · تحقّق من عرض الترقية · fandaqah.com
**Product approval needed** for the task shown at 10–20 s before recording.
**Before the price runs:** the launch period's end date and the Golden Guarantee terms (30 days from activation, full refund, previous plan restored) must be in the signed commercial release record. End card button: «احجز سعر الإطلاق» / "Reserve launch pricing". The offer is a 1-year subscription with an optional second year at the same rate: never imply a two-year commitment.
